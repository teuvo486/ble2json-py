ADD_DEVICES = []

CLEANUP_INTERVAL = {"hours": 6}

DELETE_DEVICES = []

MAX_AGE = {"weeks": 10}

NO_LISTEN = False

PERSISTENT = False

RATE_LIMIT = {"minutes": 5}

TESTING = False
